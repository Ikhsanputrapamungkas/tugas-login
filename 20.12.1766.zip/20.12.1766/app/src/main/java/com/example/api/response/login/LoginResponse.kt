package com.example.api.response.login

data class LoginResponse(
    val success:Boolean,
    val message:String,
    val data:Data
)
