package com.example.api.response.login

data class Data(
    val admin:Admin,
    val token:String
)
